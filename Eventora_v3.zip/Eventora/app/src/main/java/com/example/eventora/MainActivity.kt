package com.example.eventora

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.example.eventora.auth.AuthViewModel
import com.example.eventora.auth.LoginScreen
import com.example.eventora.auth.RegisterScreen
import com.example.eventora.navigation.Screen
import com.example.eventora.ui.theme.EventoraTheme
import com.example.eventora.event.EventListScreen
import com.example.eventora.event.EventViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var isDarkTheme by remember { mutableStateOf(false) }
            var isPolishLanguage by remember { mutableStateOf(true) }

            val navController = rememberNavController()
            val authViewModel: AuthViewModel = viewModel()
            val eventViewModel: EventViewModel = viewModel()

            LaunchedEffect(authViewModel.isLoggedIn) {
                if (authViewModel.isLoggedIn) {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(0)
                    }
                }
                if (!authViewModel.isLoggedIn) {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0)
                    }
                }
            }

            EventoraTheme(darkTheme = isDarkTheme) {
                NavHost(navController = navController, startDestination = Screen.Login.route) {
                    composable(Screen.Login.route) {
                        LoginScreen(
                            onLoginClick = { email, password ->
                                authViewModel.login(email, password)
                            },
                            errorMessage = authViewModel.loginError,
                            onRegisterNavigate = { navController.navigate(Screen.Register.route) }
                        )
                    }
                    composable(Screen.Register.route) {
                        RegisterScreen(
                            onRegisterClick = { email, password ->
                                authViewModel.register(email, password)
                            },
                            errorMessage = authViewModel.loginError,
                            onBackToLoginClick = { navController.popBackStack() }
                        )
                    }
                    composable(Screen.Main.route) {
                        MainScreen(
                            isDarkTheme = isDarkTheme,
                            onToggleTheme = { isDarkTheme = !isDarkTheme },
                            isPolishLanguage = isPolishLanguage,
                            onToggleLanguage = { isPolishLanguage = !isPolishLanguage },
                            onLogoutClick = { authViewModel.signOut() },
                            onEventsClick = { navController.navigate(Screen.Events.route) }
                        )
                    }
                    composable(Screen.Events.route) {
                        EventListScreen(viewModel = eventViewModel)
                    }
                }
            }
        }
    }
}