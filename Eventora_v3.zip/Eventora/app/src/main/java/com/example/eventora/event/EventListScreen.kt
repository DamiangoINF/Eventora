package com.example.eventora.event

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun EventListScreen(viewModel: EventViewModel) {
    val context = LocalContext.current
    val events by viewModel.events.collectAsState()

    var showDialog by remember { mutableStateOf(false) }
    var isEditing by remember { mutableStateOf(false) }
    var editEventId by remember { mutableStateOf<Int?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var dateInMillis by remember { mutableStateOf<Long?>(null) }
    var latitudeText by remember { mutableStateOf("") }
    var longitudeText by remember { mutableStateOf("") }

    val galleryLauncher = rememberLauncherForActivityResult(GetContent()) { uri ->
        if (uri != null) photoUri = uri
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {
                isEditing = false
                title = ""
                description = ""
                photoUri = null
                dateInMillis = null
                latitudeText = ""
                longitudeText = ""
                showDialog = true
            }) {
                Text("+")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Lista wydarzeń",
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                items(events) { event ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                isEditing = true
                                editEventId = event.id
                                title = event.title
                                description = event.description
                                photoUri = event.photoUri?.let { Uri.parse(it) }
                                dateInMillis = event.date
                                latitudeText = event.latitude?.toString() ?: ""
                                longitudeText = event.longitude?.toString() ?: ""
                                showDialog = true
                            }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = event.title, style = MaterialTheme.typography.titleMedium)
                                    Text(text = event.description, style = MaterialTheme.typography.bodyMedium)
                                    event.date?.let {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Data: " + SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(it),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    if (event.latitude != null && event.longitude != null) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        TextButton(onClick = {
                                            val uri = Uri.parse("geo:${event.latitude},${event.longitude}?q=${event.latitude},${event.longitude}")
                                            val intent = Intent(Intent.ACTION_VIEW, uri)
                                            intent.setPackage("com.google.android.apps.maps")
                                            context.startActivity(intent)
                                        }) {
                                            Icon(Icons.Default.Place, contentDescription = null)
                                            Spacer(Modifier.width(4.dp))
                                            Text("Zobacz lokalizację")
                                        }
                                    }
                                }
                                IconButton(onClick = { viewModel.removeEvent(event) }) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Usuń")
                                }
                            }
                            event.photoUri?.let {
                                Spacer(modifier = Modifier.height(8.dp))
                                AsyncImage(
                                    model = Uri.parse(it),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }

            if (showDialog) {
                val calendar = Calendar.getInstance()
                dateInMillis?.let { calendar.timeInMillis = it }

                val formattedDate = dateInMillis?.let {
                    SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(it)
                } ?: "Wybierz datę"

                val datePickerDialog = DatePickerDialog(
                    context,
                    { _, year, month, dayOfMonth ->
                        calendar.set(year, month, dayOfMonth)
                        dateInMillis = calendar.timeInMillis
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                )

                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    confirmButton = {
                        TextButton(onClick = {
                            val lat = latitudeText.toDoubleOrNull()
                            val lon = longitudeText.toDoubleOrNull()

                            if (title.isNotBlank()) {
                                if (isEditing && editEventId != null) {
                                    viewModel.editEvent(
                                        editEventId!!,
                                        title.trim(),
                                        description.trim(),
                                        photoUri?.toString(),
                                        dateInMillis,
                                        lat,
                                        lon
                                    )
                                } else {
                                    viewModel.addEvent(
                                        title.trim(),
                                        description.trim(),
                                        photoUri?.toString(),
                                        dateInMillis,
                                        lat,
                                        lon
                                    )
                                }
                                showDialog = false
                                title = ""
                                description = ""
                                photoUri = null
                                editEventId = null
                                dateInMillis = null
                                latitudeText = ""
                                longitudeText = ""
                            }
                        }) {
                            Text(if (isEditing) "Zapisz" else "Dodaj")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDialog = false }) {
                            Text("Anuluj")
                        }
                    },
                    title = { Text(if (isEditing) "Edytuj wydarzenie" else "Nowe wydarzenie") },
                    text = {
                        Column {
                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it },
                                label = { Text("Tytuł") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = description,
                                onValueChange = { description = it },
                                label = { Text("Opis") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(onClick = { datePickerDialog.show() }) {
                                Text(formattedDate)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row {
                                OutlinedTextField(
                                    value = latitudeText,
                                    onValueChange = { latitudeText = it },
                                    label = { Text("Szerokość (lat)") },
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                OutlinedTextField(
                                    value = longitudeText,
                                    onValueChange = { longitudeText = it },
                                    label = { Text("Długość (lon)") },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(onClick = { galleryLauncher.launch("image/*") }) {
                                    Icon(Icons.Default.Image, contentDescription = "Galeria")
                                }
                            }

                            photoUri?.let {
                                Spacer(modifier = Modifier.height(8.dp))
                                AsyncImage(
                                    model = it,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                )
            }
        }
    }
}
