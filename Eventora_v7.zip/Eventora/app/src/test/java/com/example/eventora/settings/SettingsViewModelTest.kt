package com.example.eventora.settings

import android.content.Context
import android.content.SharedPreferences
import com.example.eventora.utils.LocaleHelper
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkObject
import io.mockk.verify
import org.junit.Before
import org.junit.Test

class SettingsViewModelTest {

    private val mockContext = mockk<Context>(relaxed = true)
    private val mockPrefs = mockk<SharedPreferences>(relaxed = true)
    private val mockEditor = mockk<SharedPreferences.Editor>(relaxed = true)

    private lateinit var viewModel: SettingsViewModel

    @Before
    fun setUp() {
        every { mockContext.getSharedPreferences(any(), any()) } returns mockPrefs
        every { mockPrefs.edit() } returns mockEditor

        viewModel = SettingsViewModel()

        mockkObject(LocaleHelper)
    }

    @Test
    fun `changeLanguage - when current language is Polish - sets language to English`() {
        every { LocaleHelper.getPersistedLanguage(mockContext) } returns "pl"

        viewModel.changeLanguage(mockContext)

        verify { LocaleHelper.setLocale(mockContext, "en") }
    }

    @Test
    fun `changeLanguage - when current language is English - sets language to Polish`() {
        every { LocaleHelper.getPersistedLanguage(mockContext) } returns "en"

        viewModel.changeLanguage(mockContext)

        verify { LocaleHelper.setLocale(mockContext, "pl") }
    }
}