package com.example.eventora.event

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventora.notification.AlarmScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel zarządzający danymi wydarzeń w aplikacji Eventora.
 *
 * Klasa `EventViewModel` odpowiada za komunikację z bazą danych Room oraz zarządzanie
 * przypomnieniami (`AlarmScheduler`) dla zaplanowanych wydarzeń. Udostępnia listę
 * wydarzeń jako `StateFlow`, umożliwiając interfejsowi użytkownika ich obserwację
 * w czasie rzeczywistym.
 *
 * ## Główne funkcjonalności
 * - Pobieranie i obserwacja listy wydarzeń z bazy danych
 * - Dodawanie nowych wydarzeń (wraz z ustawieniem alarmu)
 * - Edycja istniejących wydarzeń (z aktualizacją alarmu)
 * - Usuwanie wydarzeń (z anulowaniem alarmu)
 *
 * ## Parametry konstruktora
 * @param application Aplikacja używana do uzyskania kontekstu i dostępu do bazy danych
 *
 * @property events Lista wszystkich wydarzeń w postaci strumienia `StateFlow`
 *
 * @see Event
 * @see EventDao
 * @see EventDatabase
 * @see AlarmScheduler
 */

class EventViewModel(application: Application) : AndroidViewModel(application) {

    private val eventDao: EventDao
    private val alarmScheduler: AlarmScheduler

    val events: StateFlow<List<Event>>

    init {
        val db = EventDatabase.getDatabase(application)
        eventDao = db.eventDao()
        alarmScheduler = AlarmScheduler(application.applicationContext)

        events = eventDao.getAllEvents().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun addEvent(
        title: String,
        description: String,
        photoUri: String?,
        date: Long?,
        latitude: Double? = null,
        longitude: Double? = null
    ) = viewModelScope.launch {
        val event = Event(
            title = title.trim(),
            description = description.trim(),
            photoUri = photoUri,
            date = date,
            latitude = latitude,
            longitude = longitude
        )
        val newId = eventDao.insert(event)

        alarmScheduler.schedule(event.copy(id = newId.toInt()))
    }

    fun removeEvent(event: Event) = viewModelScope.launch {
        alarmScheduler.cancel(event)
        eventDao.delete(event)
    }

    fun editEvent(
        id: Int,
        newTitle: String,
        newDescription: String,
        newPhotoUri: String?,
        newDate: Long?,
        newLatitude: Double? = null,
        newLongitude: Double? = null
    ) = viewModelScope.launch {
        val updatedEvent = Event(
            id = id,
            title = newTitle.trim(),
            description = newDescription.trim(),
            photoUri = newPhotoUri,
            date = newDate,
            latitude = newLatitude,
            longitude = newLongitude
        )
        eventDao.update(updatedEvent)
        alarmScheduler.schedule(updatedEvent)
    }
}