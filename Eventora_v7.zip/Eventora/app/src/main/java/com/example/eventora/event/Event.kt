package com.example.eventora.event

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Reprezentacja pojedynczego wydarzenia w aplikacji Eventora.
 *
 * Klasa `Event` jest encją Room i odpowiada tabeli `events` w lokalnej bazie danych.
 * Przechowuje wszystkie informacje związane z wydarzeniem, takie jak tytuł, opis, data,
 * opcjonalne zdjęcie oraz lokalizacja geograficzna.
 *
 * ## Pola danych
 * - `id` – unikalny identyfikator wydarzenia, generowany automatycznie
 * - `title` – tytuł wydarzenia
 * - `description` – szczegółowy opis wydarzenia
 * - `timestamp` – czas utworzenia wydarzenia (domyślnie aktualny czas)
 * - `photoUri` – opcjonalny URI do zdjęcia powiązanego z wydarzeniem
 * - `date` – opcjonalna planowana data wydarzenia (w formacie UNIX timestamp)
 * - `latitude` – opcjonalna szerokość geograficzna lokalizacji wydarzenia
 * - `longitude` – opcjonalna długość geograficzna lokalizacji wydarzenia
 *
 * @constructor Tworzy nowe wydarzenie z podanymi danymi.
 *
 * @see androidx.room.Entity
 * @see androidx.room.PrimaryKey
 */

@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val photoUri: String? = null,
    val date: Long? = null,
    val latitude: Double? = null,
    val longitude: Double? = null
)