package com.example.eventora.navigation

/**
 * Reprezentuje ekran w systemie nawigacji aplikacji.
 *
 * Klasa `Screen` definiuje wszystkie dostępne trasy (`route`) dla ekranów
 * w aplikacji Eventora, używane w systemie nawigacji Jetpack Compose.
 *
 * ## Dostępne ekrany:
 * - `Login` – ekran logowania użytkownika
 * - `Register` – ekran rejestracji nowego użytkownika
 * - `Main` – ekran główny po zalogowaniu
 * - `Events` – ekran listy wydarzeń
 *
 * @property route Ścieżka nawigacyjna przypisana do ekranu
 */

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object Main : Screen("main")
    object Events : Screen("events")
}