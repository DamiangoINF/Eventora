package com.example.eventora.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Motyw aplikacji Eventora oparty na Material 3.
 *
 * Plik definiuje kolorystykę aplikacji dla trybu jasnego i ciemnego oraz
 * dostarcza funkcję `EventoraTheme`, która stosuje odpowiedni schemat kolorów
 * w zależności od ustawień systemowych lub ręcznego wyboru.
 *
 * ## Funkcje:
 * - `EventoraTheme` – kompozycja opakowująca `MaterialTheme`, która stosuje
 *   odpowiednie kolory i typografię do całej aplikacji.
 *
 * ## Użycie:
 * Funkcja `EventoraTheme` powinna być używana jako najwyższy wrapper
 * w hierarchii interfejsu, zwykle w `MainActivity`.
 *
 * @param darkTheme Określa, czy ma być zastosowany ciemny motyw. Domyślnie bazuje na ustawieniach systemowych.
 * @param content Zawartość kompozycyjna, do której stosowany jest motyw.
 *
 * @see androidx.compose.material3.MaterialTheme
 * @see com.example.eventora.ui.theme.Color.kt
 */

private val LightColors = lightColorScheme(
    primary = LightPrimary,
    onPrimary = Color.White,
    background = LightBackground,
    onBackground = LightText,
    surface = LightCard,
    onSurface = LightText
)

private val DarkColors = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = Color.White,
    background = DarkBackground,
    onBackground = DarkText,
    surface = DarkCard,
    onSurface = DarkText
)

@Composable
fun EventoraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}