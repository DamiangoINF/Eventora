package com.example.eventora.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Definicje niestandardowych kolorów dla motywu aplikacji Eventora.
 *
 * Plik zawiera paletę kolorów wykorzystywaną w trybach jasnym i ciemnym aplikacji.
 * Kolory te są wykorzystywane do tworzenia spójnego i estetycznego interfejsu użytkownika,
 * niezależnie od systemowego motywu.
 *
 * ## Kolory trybu jasnego
 * - `LightBackground` – kolor tła interfejsu
 * - `LightText` – kolor tekstu
 * - `LightPrimary` – kolor akcentu / główny kolor
 * - `LightCard` – kolor kart i komponentów powierzchniowych
 *
 * ## Kolory trybu ciemnego
 * - `DarkBackground` – kolor tła interfejsu
 * - `DarkText` – kolor tekstu
 * - `DarkPrimary` – kolor akcentu / główny kolor
 * - `DarkCard` – kolor kart i komponentów powierzchniowych
 *
 * @see androidx.compose.material3.MaterialTheme
 */

val LightBackground = Color(0xFFFAFAFA)
val LightText = Color(0xFF1A1A1A)
val LightPrimary = Color(0xFF121212)
val LightCard = Color(0xFFF0F0F0)

val DarkBackground = Color(0xFF121212)
val DarkText = Color(0xFFE0E0E0)
val DarkPrimary = Color(0xFF121212)
val DarkCard = Color(0xFF2C2C2C)