package com.example.eventora.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.eventora.MainActivity
import com.example.eventora.R

/**
 * Odbiornik `BroadcastReceiver` odpowiedzialny za wyświetlanie powiadomień o wydarzeniach.
 *
 * Klasa `NotificationReceiver` nasłuchuje alarmów zaplanowanych przez `AlarmScheduler`
 * i generuje powiadomienia systemowe dla odpowiednich wydarzeń.
 *
 * ## Główne funkcje
 * - `onReceive()` – odbiera dane o wydarzeniu (ID, tytuł, opis) i wywołuje powiadomienie.
 * - `showNotification()` – tworzy i wyświetla powiadomienie z kanałem dla Androida 8+.
 *
 * Powiadomienie zawiera:
 * - tytuł wydarzenia
 * - opis wydarzenia
 * - akcję otwierającą `MainActivity`
 *
 * @see AlarmScheduler
 * @see android.app.NotificationManager
 * @see androidx.core.app.NotificationCompat
 */

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val eventId = intent.getIntExtra("EXTRA_EVENT_ID", -1)
        val title = intent.getStringExtra("EXTRA_EVENT_TITLE") ?: return
        val description = intent.getStringExtra("EXTRA_EVENT_DESC") ?: ""

        if (eventId != -1) {
            showNotification(context, eventId, title, description)
        }
    }

    private fun showNotification(context: Context, eventId: Int, title: String, message: String) {
        val channelId = "event_notifications"
        val channelName = context.getString(R.string.notification_channel_name)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT)
            manager.createNotificationChannel(channel)
        }

        val activityIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, eventId, activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationTitle = context.getString(R.string.notification_title, title)

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(notificationTitle)
            .setContentText(message)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(eventId, notification)
    }
}