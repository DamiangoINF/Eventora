package com.example.eventora.event

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.eventora.R // <-- WAŻNE: Dodaj ten import
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * Generuje plik PDF na podstawie danych wydarzenia.
 *
 * Funkcja tworzy dokument PDF zawierający:
 * - tytuł, opis i datę wydarzenia,
 * - opcjonalne zdjęcie, jeśli zostało dodane do wydarzenia.
 *
 * Zapisuje plik do katalogu `Downloads`, z obsługą zarówno nowszych, jak i starszych wersji Androida.
 * Nazwa pliku generowana jest na podstawie tytułu wydarzenia.
 *
 * ## Obsługa zdjęć
 * Jeśli wydarzenie zawiera `photoUri`, obraz jest skalowany i dodawany do dokumentu PDF.
 * Obsługiwane są zdjęcia z galerii i aparatu.
 *
 * @param context Kontekst aplikacji używany do odczytu zasobów i dostępu do systemu plików
 * @param event Obiekt `Event`, na podstawie którego generowany jest PDF
 *
 * @see PdfDocument
 * @see Event
 * @see MediaStore.Downloads
 */

fun generatePdfFromEvent(context: Context, event: Event) {
    val document = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = document.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint()

    var yPos = 40f

    val titleLabel = context.getString(R.string.pdf_title_label)
    val descriptionLabel = context.getString(R.string.pdf_description_label)
    val dateLabel = context.getString(R.string.pdf_date_label)
    val noDateLabel = context.getString(R.string.pdf_no_date_available)

    canvas.drawText("$titleLabel: ${event.title}", 40f, yPos, paint)
    yPos += 30
    canvas.drawText("$descriptionLabel: ${event.description}", 40f, yPos, paint)
    yPos += 30
    val dateFormatted = event.date?.let {
        SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(it)
    } ?: noDateLabel
    canvas.drawText("$dateLabel: $dateFormatted", 40f, yPos, paint)
    yPos += 40

    event.photoUri?.let { uriString ->
        try {
            val uri = Uri.parse(uriString)
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (originalBitmap != null) {
                val scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, 400, 300, true)
                canvas.drawBitmap(scaledBitmap, 40f, yPos, null)
                yPos += scaledBitmap.height + 20
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    document.finishPage(page)

    val filename = "event_${event.title.replace(" ", "_")}.pdf"
    val outputStream = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
        uri?.let { resolver.openOutputStream(it) }
    } else {
        @Suppress("DEPRECATION")
        val path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val file = java.io.File(path, filename)
        file.outputStream()
    }

    outputStream?.use { document.writeTo(it) }
    document.close()
}