package com.example.eventora.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.eventora.R
import com.example.eventora.event.EventDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Dostawca widżetu aplikacji Eventora.
 *
 * Klasa `EventAppWidgetProvider` zarządza aktualizacją widżetu systemowego wyświetlającego
 * najbliższe nadchodzące wydarzenie zapisane w bazie danych aplikacji.
 *
 * Widżet automatycznie pobiera najbliższe wydarzenie i wyświetla jego tytuł, opis oraz datę.
 * Obsługuje również ręczne odświeżenie poprzez kliknięcie ikony odświeżania w widżecie.
 *
 * ## Główne funkcje:
 * - `onUpdate` – wywoływane przez system przy aktualizacji widżetu.
 * - `onReceive` – obsługuje akcję odświeżenia widżetu.
 * - `updateWidget` – pobiera najbliższe wydarzenie z bazy danych i aktualizuje UI widżetu.
 *
 * @see android.appwidget.AppWidgetProvider
 * @see android.widget.RemoteViews
 * @see com.example.eventora.event.EventDatabase
 */

class EventAppWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH_WIDGET = "com.example.eventora.action.REFRESH_WIDGET"
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        super.onUpdate(context, appWidgetManager, appWidgetIds)
        updateWidget(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH_WIDGET) {
            updateWidget(context)
        }
    }

    private fun updateWidget(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            val dao = EventDatabase.getDatabase(context).eventDao()

            val upcomingEvents = dao.getFutureEvents(System.currentTimeMillis())

            val nextEvent = upcomingEvents.firstOrNull()

            val views = RemoteViews(context.packageName, R.layout.event_widget)

            if (nextEvent != null) {
                val datePrefix = context.getString(R.string.widget_date_prefix)
                val formattedDate = nextEvent.date?.let {
                    SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(it)
                } ?: ""

                views.setTextViewText(R.id.widget_title, nextEvent.title)
                views.setTextViewText(R.id.widget_description, nextEvent.description)
                views.setTextViewText(R.id.widget_date, "$datePrefix $formattedDate")
            } else {
                views.setTextViewText(R.id.widget_title, context.getString(R.string.widget_no_upcoming_events))
                views.setTextViewText(R.id.widget_description, "")
                views.setTextViewText(R.id.widget_date, "")
            }

            val refreshIntent = Intent(context, EventAppWidgetProvider::class.java).apply {
                action = ACTION_REFRESH_WIDGET
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, pendingIntent)

            val manager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, EventAppWidgetProvider::class.java)
            manager.updateAppWidget(componentName, views)
        }
    }
}