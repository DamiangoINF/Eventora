package com.example.eventora.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Styl typografii używany w aplikacji Eventora.
 *
 * Plik definiuje podstawowy zestaw stylów tekstu dla MaterialTheme w Compose.
 * Aktualnie zdefiniowany jest tylko styl `bodyLarge`, który może być rozszerzony
 * o kolejne style w razie potrzeby.
 *
 * ## Zdefiniowane style:
 * - `bodyLarge` – domyślny styl tekstu dla większych bloków treści.
 *
 * @see androidx.compose.material3.Typography
 * @see androidx.compose.ui.text.TextStyle
 */

val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    )
)