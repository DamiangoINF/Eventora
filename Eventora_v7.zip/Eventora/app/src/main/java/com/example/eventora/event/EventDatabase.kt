package com.example.eventora.event

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Główna klasa bazy danych Room dla aplikacji Eventora.
 *
 * Klasa `EventDatabase` definiuje konfigurację lokalnej bazy danych SQLite
 * oraz zapewnia dostęp do interfejsu DAO (`EventDao`) obsługującego operacje na wydarzeniach.
 * Wykorzystuje wzorzec Singleton do zapewnienia jednej instancji bazy danych w aplikacji.
 *
 * ## Funkcjonalności
 * - Tworzy bazę danych o nazwie `event_database`
 * - Umożliwia dostęp do DAO przez metodę `eventDao()`
 * - Zapewnia bezpieczne współdzielenie instancji dzięki `@Volatile` i `synchronized`
 *
 * @property INSTANCE Statyczna, współdzielona instancja bazy danych
 * @see Event
 * @see EventDao
 * @see androidx.room.RoomDatabase
 */

@Database(entities = [Event::class], version = 4)
abstract class EventDatabase : RoomDatabase() {

    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var INSTANCE: EventDatabase? = null

        fun getDatabase(context: Context): EventDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EventDatabase::class.java,
                    "event_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}