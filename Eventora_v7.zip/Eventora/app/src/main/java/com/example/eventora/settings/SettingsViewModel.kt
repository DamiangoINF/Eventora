package com.example.eventora.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import com.example.eventora.utils.LocaleHelper

/**
 * ViewModel odpowiedzialny za ustawienia językowe aplikacji Eventora.
 *
 * Klasa `SettingsViewModel` zarządza zmianą języka interfejsu użytkownika między polskim a angielskim.
 * Wykorzystuje `LocaleHelper` do zapisywania i stosowania wybranego języka.
 *
 * ## Główne funkcje
 * - `changeLanguage()` – przełącza język aplikacji z "pl" na "en" lub odwrotnie
 *   i zapisuje nowy wybór w preferencjach.
 *
 * @param context Kontekst aplikacji wymagany do odczytu i zapisu ustawień lokalizacji.
 *
 * @see com.example.eventora.utils.LocaleHelper
 */

class SettingsViewModel : ViewModel() {
    fun changeLanguage(context: Context) {
        val currentLang = LocaleHelper.getPersistedLanguage(context)

        val newLang = if (currentLang == "pl") "en" else "pl"

        LocaleHelper.setLocale(context, newLang)
    }
}