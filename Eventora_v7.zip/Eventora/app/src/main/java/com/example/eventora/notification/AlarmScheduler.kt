package com.example.eventora.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.eventora.event.Event

/**
 * Klasa odpowiedzialna za planowanie i anulowanie alarmów powiązanych z wydarzeniami.
 *
 * `AlarmScheduler` korzysta z systemowego `AlarmManager`, aby zaplanować przypomnienie (powiadomienie)
 * dla wydarzenia na określoną datę. Jeśli data wydarzenia jest przeszła lub nieokreślona, alarm nie jest ustawiany.
 *
 * ## Główne funkcje
 * - `schedule(event: Event)` – ustawia dokładny alarm dla podanego wydarzenia, jeżeli jego data jest przyszła.
 * - `cancel(event: Event)` – anuluje wcześniej ustawiony alarm dla podanego wydarzenia.
 *
 * @param context Kontekst aplikacji, wymagany do uzyskania dostępu do `AlarmManager` i `PendingIntent`.
 *
 * @see android.app.AlarmManager
 * @see android.app.PendingIntent
 * @see NotificationReceiver
 */

class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(AlarmManager::class.java)

    fun schedule(event: Event) {
        val eventDate = event.date ?: return

        if (eventDate < System.currentTimeMillis()) {
            return
        }

        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra("EXTRA_EVENT_ID", event.id)
            putExtra("EXTRA_EVENT_TITLE", event.title)
            putExtra("EXTRA_EVENT_DESC", event.description)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            event.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    eventDate,
                    pendingIntent
                )
            } else {
                alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    eventDate,
                    pendingIntent
                )
            }
        } else {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                eventDate,
                pendingIntent
            )
        }
    }

    fun cancel(event: Event) {
        val intent = Intent(context, NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            event.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}