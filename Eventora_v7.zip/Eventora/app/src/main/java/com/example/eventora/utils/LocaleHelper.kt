package com.example.eventora.utils

import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.os.LocaleList
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

/**
 * Narzędzie pomocnicze do zarządzania językiem aplikacji Eventora.
 *
 * Klasa `LocaleHelper` odpowiada za zapisywanie, pobieranie i stosowanie preferowanego języka
 * użytkownika (np. "pl" lub "en") w aplikacji. Obsługuje dynamiczną zmianę języka interfejsu
 * oraz jego trwałość przy ponownym uruchomieniu aplikacji.
 *
 * ## Główne funkcje:
 * - `setLocale(context, languageCode)` – ustawia nowy język aplikacji i zapisuje go w `SharedPreferences`.
 * - `onAttach(context)` – stosuje zapisany język przy starcie aplikacji.
 * - `getPersistedLanguage(context)` – zwraca aktualnie zapisany język użytkownika.
 *
 * Obsługiwane są urządzenia od wersji Android 6.0 wzwyż, z różnicami w konfiguracji zależnie od API.
 *
 * @see androidx.appcompat.app.AppCompatDelegate
 * @see android.content.ContextWrapper
 * @see java.util.Locale
 */

object LocaleHelper {

    private const val PREFS_NAME = "language_prefs"
    private const val KEY_LANGUAGE = "selected_language"

    fun setLocale(context: Context, languageCode: String) {
        persistLanguage(context, languageCode)
        updateLocaleConfiguration(context, Locale(languageCode))
    }

    fun onAttach(context: Context): ContextWrapper {
        val savedLang = getPersistedLanguage(context)
        val locale = Locale(savedLang)
        return updateLocaleConfiguration(context, locale)
    }

    private fun persistLanguage(context: Context, languageCode: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANGUAGE, languageCode).apply()
    }

    fun getPersistedLanguage(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LANGUAGE, "pl") ?: "pl"
    }

    private fun updateLocaleConfiguration(context: Context, locale: Locale): ContextWrapper {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val config = context.resources.configuration
            config.setLocale(locale)
            val localeList = LocaleList(locale)
            LocaleList.setDefault(localeList)
            config.setLocales(localeList)
            context.createConfigurationContext(config)
        }
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.create(locale))

        val configuration = context.resources.configuration
        configuration.setLocale(locale)
        val contextWrapper = context.createConfigurationContext(configuration)
        return ContextWrapper(contextWrapper)
    }
}