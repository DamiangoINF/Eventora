package com.example.eventora.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Odbiornik ekranu do odświeżania widżetu Eventora.
 *
 * Klasa `ScreenReceiver` nasłuchuje na akcję włączenia ekranu (`ACTION_SCREEN_ON`)
 * i automatycznie wysyła żądanie odświeżenia widżetu aplikacji, aby zapewnić
 * aktualność wyświetlanych danych po odblokowaniu urządzenia.
 *
 * ## Główne funkcje:
 * - `onReceive` – wykrywa akcję włączenia ekranu i wysyła broadcast do `EventAppWidgetProvider`.
 *
 * @see android.content.BroadcastReceiver
 * @see EventAppWidgetProvider
 */

class ScreenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_SCREEN_ON) {
            val refreshIntent = Intent(context, EventAppWidgetProvider::class.java).apply {
                action = EventAppWidgetProvider.ACTION_REFRESH_WIDGET
            }

            context.sendBroadcast(refreshIntent)
        }
    }
}