package com.example.eventora.event

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Interfejs DAO do zarządzania operacjami na tabeli `events` w bazie danych Room.
 *
 * Zawiera metody umożliwiające:
 * - Pobieranie wszystkich wydarzeń w postaci strumienia (z automatycznym odświeżaniem)
 * - Wstawianie nowych wydarzeń (lub ich aktualizację przy konflikcie)
 * - Usuwanie i edycję wydarzeń
 * - Pobieranie tylko przyszłych wydarzeń względem podanego czasu
 *
 * ## Dostępne operacje
 * - `getAllEvents()` – strumień wszystkich wydarzeń posortowanych malejąco według ID
 * - `insert(event)` – dodaje nowe wydarzenie lub aktualizuje istniejące
 * - `delete(event)` – usuwa wskazane wydarzenie
 * - `update(event)` – aktualizuje istniejące wydarzenie
 * - `getFutureEvents(currentTimeMillis)` – zwraca listę przyszłych wydarzeń względem podanego czasu
 *
 * @see Event
 * @see androidx.room.Dao
 */

@Dao
interface EventDao {

    @Query("SELECT * FROM events ORDER BY id DESC")
    fun getAllEvents(): Flow<List<Event>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: Event): Long

    @Delete
    suspend fun delete(event: Event)

    @Update
    suspend fun update(event: Event)

    // @Query("SELECT * FROM events")
    // suspend fun getAllEventsOnce(): List<Event>

    @Query("SELECT * FROM events WHERE date > :currentTimeMillis ORDER BY date ASC")
    suspend fun getFutureEvents(currentTimeMillis: Long): List<Event>
}