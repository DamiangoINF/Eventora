package com.example.eventora.auth

import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.example.eventora.R

/**
 * ViewModel odpowiedzialny za uwierzytelnianie użytkownika w aplikacji Eventora.
 *
 * Klasa `AuthViewModel` zarządza procesami logowania, rejestracji oraz wylogowania,
 * wykorzystując Firebase Authentication jako usługę zaplecza. Przechowuje również informacje
 * o stanie błędów logowania/rejestracji oraz aktualnym zalogowaniu użytkownika.
 *
 * ## Funkcjonalności
 * - Logowanie użytkownika przez email i hasło
 * - Rejestracja nowego konta użytkownika
 * - Obsługa błędów za pomocą identyfikatorów zasobów stringów (`loginErrorResId`)
 * - Automatyczne wykrywanie stanu zalogowania przy inicjalizacji
 * - Wylogowanie użytkownika
 *
 * @property loginErrorResId Identyfikator zasobu błędu do wyświetlenia na UI.
 * @property isLoggedIn Informacja o tym, czy użytkownik jest aktualnie zalogowany.
 *
 * @see FirebaseAuth
 * @see androidx.lifecycle.ViewModel
 */

class AuthViewModel : ViewModel() {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    var loginErrorResId by mutableStateOf<Int?>(null)
        private set

    var isLoggedIn by mutableStateOf(false)
        private set

    init {
        isLoggedIn = auth.currentUser != null
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            loginErrorResId = R.string.auth_error_credentials_required
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    loginErrorResId = null
                    isLoggedIn = true
                } else {
                    loginErrorResId = R.string.auth_error_login_failed
                    isLoggedIn = false
                }
            }
    }

    fun register(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            loginErrorResId = R.string.auth_error_credentials_required
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    loginErrorResId = null
                    isLoggedIn = true
                } else {
                    loginErrorResId = R.string.auth_error_registration_failed
                    isLoggedIn = false
                }
            }
    }

    fun signOut() {
        auth.signOut()
        isLoggedIn = false
    }
}