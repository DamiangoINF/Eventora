package com.example.eventora

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.eventora.ui.theme.EventoraTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.atomic.AtomicBoolean

@RunWith(AndroidJUnit4::class)
class MainScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun mainScreen_displaysAllRequiredElements() {
        composeTestRule.setContent {
            val context = LocalContext.current
            val welcomeText = context.getString(R.string.welcome_text)
            val eventsButtonText = context.getString(R.string.events)
            val testNotificationButtonText = context.getString(R.string.main_screen_test_notification)

            EventoraTheme {
                MainScreen(
                    isDarkTheme = false,
                    onToggleTheme = {},
                    onChangeLanguage = {},
                    onLogoutClick = {},
                    onEventsClick = {},
                    onTestNotificationClick = {}
                )
            }

            composeTestRule.onNodeWithText(welcomeText).assertIsDisplayed()
            composeTestRule.onNodeWithText(eventsButtonText).assertIsDisplayed()
            composeTestRule.onNodeWithText(testNotificationButtonText).assertIsDisplayed()
            composeTestRule.onNodeWithTag("ToggleThemeButton").assertIsDisplayed()
            composeTestRule.onNodeWithTag("ToggleLanguageButton").assertIsDisplayed()
        }
    }

    @Test
    fun onEventsClick_isCalled_whenEventsButtonIsClicked() {
        val onEventsClickCalled = AtomicBoolean(false)

        composeTestRule.setContent {
            val context = LocalContext.current
            val eventsButtonText = context.getString(R.string.events)

            EventoraTheme {
                MainScreen(
                    isDarkTheme = false,
                    onToggleTheme = {},
                    onChangeLanguage = {},
                    onLogoutClick = {},
                    onEventsClick = { onEventsClickCalled.set(true) },
                    onTestNotificationClick = {}
                )
            }

            composeTestRule.onNodeWithText(eventsButtonText).performClick()
        }

        assert(onEventsClickCalled.get())
    }
}