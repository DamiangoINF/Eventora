package com.example.eventora.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.eventora.MainActivity
import com.example.eventora.R
import com.example.eventora.event.EventDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        CoroutineScope(Dispatchers.IO).launch {
            val dao = EventDatabase.getDatabase(context).eventDao()
            val events = dao.getAllEventsOnce()

            val calendar = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
            val tomorrow = calendar.get(Calendar.DAY_OF_YEAR)

            val upcoming = events.firstOrNull { it.date?.let { dateMillis ->
                val eventCal = Calendar.getInstance().apply { timeInMillis = dateMillis }
                eventCal.get(Calendar.DAY_OF_YEAR) == tomorrow
            } == true }

            if (upcoming != null) {
                showNotification(context, upcoming.title, upcoming.description)
            }
        }
    }

    private fun showNotification(context: Context, title: String, message: String) {
        val channelId = "event_notifications"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Event Reminders", NotificationManager.IMPORTANCE_DEFAULT)
            manager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Przypomnienie: $title")
            .setContentText(message)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(1, notification)
    }
}