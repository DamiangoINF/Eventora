package com.example.eventora

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.eventora.ui.theme.EventoraTheme
import androidx.compose.material.icons.filled.Event

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    isPolishLanguage: Boolean,
    onToggleLanguage: () -> Unit,
    onLogoutClick: () -> Unit,
    onEventsClick: () -> Unit
) {
    val contentColor = MaterialTheme.colorScheme.onBackground
    val backgroundColor = MaterialTheme.colorScheme.background

    Scaffold(
        containerColor = backgroundColor,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Eventora",
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Black,
                    actionIconContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = onToggleTheme) {
                        Icon(
                            imageVector = Icons.Default.Brightness4,
                            contentDescription = "Zmień motyw",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = onToggleLanguage) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Zmień język",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = onEventsClick) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = "Wydarzenia",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = onLogoutClick) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Wyloguj się",
                            tint = Color.White
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isPolishLanguage) "Witaj w Eventora!" else "Welcome to Eventora!",
                color = contentColor
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    EventoraTheme(darkTheme = false) {
        MainScreen(
            isDarkTheme = false,
            onToggleTheme = {},
            isPolishLanguage = true,
            onToggleLanguage = {},
            onLogoutClick = {},
            onEventsClick = {}
        )
    }
}