package com.example.eventora.event

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class EventViewModel(application: Application) : AndroidViewModel(application) {

    private val eventDao: EventDao

    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> = _events.asStateFlow()

    init {
        val db = Room.databaseBuilder(
            application,
            EventDatabase::class.java,
            "event_database"
        )
            .fallbackToDestructiveMigration()
            .build()

        eventDao = db.eventDao()

        viewModelScope.launch {
            eventDao.getAllEvents().collectLatest { list ->
                _events.value = list
            }
        }
    }

    fun addEvent(title: String, description: String, photoUri: String?, date: Long?) {
        viewModelScope.launch {
            val event = Event(title = title, description = description, photoUri = photoUri, date = date)
            eventDao.insert(event)
        }
    }

    fun removeEvent(event: Event) {
        viewModelScope.launch {
            eventDao.delete(event)
        }
    }

    fun editEvent(id: Int, newTitle: String, newDescription: String, newPhotoUri: String?, newDate: Long?) {
        viewModelScope.launch {
            val updated = Event(id = id, title = newTitle, description = newDescription, photoUri = newPhotoUri, date = newDate)
            eventDao.update(updated)
        }
    }
}
