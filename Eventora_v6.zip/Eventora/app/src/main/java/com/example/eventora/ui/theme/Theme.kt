package com.example.eventora.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Główny motyw kolorystyczny aplikacji Eventora.
 *
 * Komponent `EventoraTheme` dostosowuje styl aplikacji do wybranego motywu – jasnego lub ciemnego.
 * Wykorzystuje wcześniej zdefiniowane kolory (`LightColors` i `DarkColors`) oraz typografię.
 * Motyw wpływa na wygląd wszystkich komponentów Material Design w aplikacji.
 *
 * ## Funkcjonalności
 * - Automatyczne dostosowanie do systemowego motywu (jeśli nie określono ręcznie)
 * - Użycie spójnych schematów kolorów i czcionek w całej aplikacji
 *
 * @param darkTheme Określa, czy aktywowany ma być ciemny motyw. Domyślnie pobierany z ustawień systemu.
 * @param content Kompozycje, do których stosowany będzie motyw.
 *
 * @see androidx.compose.material3.MaterialTheme
 * @see androidx.compose.material3.lightColorScheme
 * @see androidx.compose.material3.darkColorScheme
 */

private val LightColors = lightColorScheme(
    primary = LightPrimary,
    onPrimary = Color.White,
    background = LightBackground,
    onBackground = LightText,
    surface = LightCard,
    onSurface = LightText
)

private val DarkColors = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = Color.White,
    background = DarkBackground,
    onBackground = DarkText,
    surface = DarkCard,
    onSurface = DarkText
)

@Composable
fun EventoraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}