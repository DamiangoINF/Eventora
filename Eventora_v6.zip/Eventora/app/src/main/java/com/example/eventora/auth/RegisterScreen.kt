package com.example.eventora.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Ekran rejestracji użytkownika w aplikacji Eventora.
 *
 * Komponent `RegisterScreen` umożliwia użytkownikowi utworzenie nowego konta,
 * wprowadzając adres email i hasło. Udostępnia również opcję powrotu do ekranu logowania
 * oraz wyświetlania błędów rejestracji.
 *
 * ## Funkcjonalności
 * - Wprowadzanie adresu e-mail i hasła
 * - Przycisk do rejestracji nowego konta
 * - Powrót do ekranu logowania
 * - Wyświetlanie komunikatów o błędach rejestracji
 *
 * @param onRegisterClick Funkcja callback wywoływana po kliknięciu przycisku rejestracji.
 *                        Otrzymuje email i hasło jako argumenty.
 * @param errorMessage Opcjonalny komunikat błędu wyświetlany pod formularzem.
 * @param onBackToLoginClick Funkcja callback umożliwiająca przejście z powrotem do ekranu logowania.
 *
 * @sample
 * ```kotlin
 * RegisterScreen(
 *     onRegisterClick = { email, password -> register(email, password) },
 *     errorMessage = "Błąd rejestracji",
 *     onBackToLoginClick = { navigateToLogin() }
 * )
 * ```
 *
 * @see androidx.compose.material3.OutlinedTextField
 * @see androidx.compose.material3.Button
 * @see androidx.compose.material3.TextButton
 */
@Composable
fun RegisterScreen(
    onRegisterClick: (String, String) -> Unit,
    errorMessage: String?,
    onBackToLoginClick: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Zarejestruj się",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Hasło") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { onRegisterClick(email.trim(), password) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Zarejestruj")
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = onBackToLoginClick) {
            Text("Masz już konto? Zaloguj się")
        }

        if (!errorMessage.isNullOrEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
    }
}