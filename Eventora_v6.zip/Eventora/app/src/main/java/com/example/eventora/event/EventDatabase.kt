package com.example.eventora.event

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Lokalna baza danych Room dla wydarzeń w aplikacji Eventora.
 *
 * Klasa `EventDatabase` definiuje bazę danych przechowującą obiekty typu `Event`.
 * Umożliwia dostęp do DAO (`EventDao`) oraz zapewnia singletonową instancję bazy danych.
 *
 * ## Funkcjonalności
 * - Tworzenie bazy danych z tabelą `Event`
 * - Udostępnienie DAO do operacji na danych
 * - Zapewnienie jedynej instancji bazy (singleton) w całej aplikacji
 *
 * @see androidx.room.RoomDatabase
 * @see EventDao
 */
@Database(entities = [Event::class], version = 4)
abstract class EventDatabase : RoomDatabase() {

    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var INSTANCE: EventDatabase? = null

        fun getDatabase(context: Context): EventDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EventDatabase::class.java,
                    "event_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}