package com.example.eventora.auth

import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/**
 * ViewModel odpowiedzialny za logikę autoryzacji użytkownika.
 *
 * Klasa `AuthViewModel` zarządza procesem logowania, rejestracji oraz wylogowania
 * użytkownika przy użyciu Firebase Authentication. Przechowuje aktualny stan logowania
 * oraz ewentualne błędy autoryzacji.
 *
 * ## Funkcjonalności
 * - Logowanie użytkownika za pomocą adresu e-mail i hasła
 * - Rejestracja nowego użytkownika
 * - Wylogowanie użytkownika
 * - Obsługa błędów logowania/rejestracji i przekazywanie ich do UI
 *
 * ## Pola
 * @property loginError Przechowuje komunikat błędu autoryzacji (jeśli wystąpił).
 * @property isLoggedIn Określa, czy użytkownik jest zalogowany.
 *
 * @see com.google.firebase.auth.FirebaseAuth
 * @see androidx.lifecycle.ViewModel
 */
class AuthViewModel : ViewModel() {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    var loginError by mutableStateOf<String?>(null)
        private set

    var isLoggedIn by mutableStateOf(false)
        private set

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            loginError = "Email i hasło są wymagane"
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    loginError = null
                    isLoggedIn = true
                } else {
                    loginError = task.exception?.message ?: "Błąd logowania"
                    isLoggedIn = false
                }
            }
    }

    fun register(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            loginError = "Email i hasło są wymagane"
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    loginError = null
                    isLoggedIn = true
                } else {
                    loginError = task.exception?.message ?: "Błąd rejestracji"
                    isLoggedIn = false
                }
            }
    }

    fun signOut() {
        auth.signOut()
        isLoggedIn = false
    }
}