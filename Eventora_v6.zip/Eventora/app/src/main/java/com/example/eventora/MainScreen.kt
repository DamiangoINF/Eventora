package com.example.eventora

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.testTag

/**
 * Główny ekran aplikacji Eventora.
 *
 * Ten komponent reprezentuje główny ekran aplikacji, który zawiera:
 * - Górny pasek z tytułem aplikacji i przyciskami sterowania
 * - Centralną sekcję z tekstem powitalnym i przyciskiem nawigacji
 * - Automatycznie przewijający się pasek reklam na dole ekranu
 *
 * Ekran automatycznie dostosowuje się do aktualnego motywu kolorystycznego oraz
 * języka interfejsu użytkownika.
 *
 * ## Funkcjonalności
 * - Przełączanie między jasnym a ciemnym motywem
 * - Zmiana języka interfejsu (polski/angielski)
 * - Wylogowanie użytkownika
 * - Nawigacja do listy wydarzeń
 * - Automatyczna rotacja reklam co 5 sekund
 *
 * @param isDarkTheme Określa, czy aktywny jest ciemny motyw interfejsu.
 *                    Wpływa na kolory używane w komponencie.
 * @param onToggleTheme Funkcja callback uruchamiana po kliknięciu przycisku
 *                      zmiany motywu. Powinna przełączać stan motywu w aplikacji.
 * @param isPolishLanguage Określa, czy aktualnie wybrany język to polski.
 *                         Wpływa na wyświetlane teksty w interfejsie.
 * @param onToggleLanguage Funkcja callback uruchamiana po kliknięciu przycisku
 *                         zmiany języka. Powinna przełączać język aplikacji.
 * @param onLogoutClick Funkcja callback uruchamiana po kliknięciu przycisku
 *                      wylogowania. Powinna przeprowadzić proces wylogowania użytkownika.
 * @param onEventsClick Funkcja callback uruchamiana po kliknięciu przycisku
 *                      "Wydarzenia"/"Events". Powinna nawigować do ekranu z listą wydarzeń.
 *
 * @sample
 * ```kotlin
 * MainScreen(
 *     isDarkTheme = false,
 *     onToggleTheme = { /* toggle theme logic */ },
 *     isPolishLanguage = true,
 *     onToggleLanguage = { /* toggle language logic */ },
 *     onLogoutClick = { /* logout logic */ },
 *     onEventsClick = { /* navigate to events */ }
 * )
 * ```
 *
 * @see androidx.compose.material3.Scaffold
 * @see androidx.compose.material3.CenterAlignedTopAppBar
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    isPolishLanguage: Boolean,
    onToggleLanguage: () -> Unit,
    onLogoutClick: () -> Unit,
    onEventsClick: () -> Unit
) {

    val ads = listOf(
        R.drawable.ad1,
        R.drawable.ad2,
        R.drawable.ad3
    )

    var currentAdIndex by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            currentAdIndex = (currentAdIndex + 1) % ads.size
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {

            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Eventora",
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                actions = {

                    IconButton(onClick = onToggleTheme, modifier = Modifier.testTag("ToggleThemeButton")) {
                        Icon(Icons.Default.Brightness4, contentDescription = "Toggle Theme", tint = MaterialTheme.colorScheme.onPrimary)
                    }

                    IconButton(onClick = onToggleLanguage, modifier = Modifier.testTag("ToggleLanguageButton")) {
                        Icon(Icons.Default.Language, contentDescription = "Toggle Language", tint = MaterialTheme.colorScheme.onPrimary)
                    }

                    IconButton(onClick = onLogoutClick) {
                        Icon(Icons.Default.ExitToApp, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        }
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = if (isPolishLanguage) "Witaj w Eventora!" else "Welcome to Eventora!",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("GreetingText"),
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = onEventsClick) {
                    Icon(Icons.Default.Event, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = if (isPolishLanguage) "Wydarzenia" else "Events")
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .padding(bottom = 24.dp)
            ) {

                Image(
                    painter = painterResource(id = ads[currentAdIndex]),
                    contentDescription = "Reklama",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}