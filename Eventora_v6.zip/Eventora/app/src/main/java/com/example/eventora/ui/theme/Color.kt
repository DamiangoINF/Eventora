package com.example.eventora.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Definicje kolorów dla motywów jasnego i ciemnego w aplikacji Eventora.
 *
 * Ten plik zawiera stałe kolorystyczne wykorzystywane w interfejsie użytkownika aplikacji.
 * Kolory są podzielone na wersje dla motywu jasnego i ciemnego i służą do ujednolicenia
 * stylizacji komponentów Material Design.
 *
 * ## Kolory jasnego motywu
 * - `LightBackground`: kolor tła aplikacji
 * - `LightText`: kolor tekstu
 * - `LightPrimary`: kolor główny (akcent)
 * - `LightCard`: kolor kart i elementów interaktywnych

 * ## Kolory ciemnego motywu
 * - `DarkBackground`: kolor tła aplikacji
 * - `DarkText`: kolor tekstu
 * - `DarkPrimary`: kolor główny (akcent)
 * - `DarkCard`: kolor kart i elementów interaktywnych
 *
 * @see androidx.compose.material3.MaterialTheme
 * @see androidx.compose.ui.graphics.Color
 */
val LightBackground = Color(0xFFFAFAFA)
val LightText = Color(0xFF1A1A1A)
val LightPrimary = Color(0xFF121212)
val LightCard = Color(0xFFF0F0F0)

val DarkBackground = Color(0xFF121212)
val DarkText = Color(0xFFE0E0E0)
val DarkPrimary = Color(0xFF121212)
val DarkCard = Color(0xFF2C2C2C)