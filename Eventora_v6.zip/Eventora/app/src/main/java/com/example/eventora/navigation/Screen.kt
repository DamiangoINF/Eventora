package com.example.eventora.navigation

/**
 * Definicja ekranów nawigacyjnych w aplikacji Eventora.
 *
 * Klasa sealed `Screen` reprezentuje wszystkie możliwe ekrany (destynacje) w aplikacji
 * wraz z odpowiadającymi im ścieżkami nawigacyjnymi. Ułatwia korzystanie z nawigacji
 * Compose poprzez jednoznaczne identyfikowanie ekranów.
 *
 * ## Zdefiniowane ekrany
 * - `Login` – ekran logowania użytkownika (`"login"`)
 * - `Register` – ekran rejestracji nowego użytkownika (`"register"`)
 * - `Main` – główny ekran po zalogowaniu (`"main"`)
 * - `Events` – ekran listy wydarzeń (`"events"`)
 *
 * @property route Ścieżka nawigacyjna przypisana do danego ekranu.
 *
 * @sample
 * ```kotlin
 * navController.navigate(Screen.Main.route)
 * ```
 *
 * @see androidx.navigation.compose.NavHost
 * @see androidx.navigation.compose.composable
 */
sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object Main : Screen("main")
    object Events : Screen("events")
}