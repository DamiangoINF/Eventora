package com.example.eventora.event

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.eventora.R
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun EventListScreen(viewModel: EventViewModel) {
    val context = LocalContext.current
    val events by viewModel.events.collectAsState()

    var showDialog by remember { mutableStateOf(false) }
    var isEditing by remember { mutableStateOf(false) }
    var editEventId by remember { mutableStateOf<Int?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var dateInMillis by remember { mutableStateOf<Long?>(null) }
    var latitudeText by remember { mutableStateOf("") }
    var longitudeText by remember { mutableStateOf("") }

    val galleryLauncher = rememberLauncherForActivityResult(GetContent()) { uri ->
        if (uri != null) photoUri = uri
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {
                isEditing = false
                editEventId = null
                title = ""
                description = ""
                photoUri = null
                dateInMillis = null
                latitudeText = ""
                longitudeText = ""
                showDialog = true
            }) {
                Text(stringResource(id = R.string.add_new_event_fab))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = stringResource(id = R.string.events_list_title),
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(events) { event ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                isEditing = true
                                editEventId = event.id
                                title = event.title
                                description = event.description
                                photoUri = event.photoUri?.let { Uri.parse(it) }
                                dateInMillis = event.date
                                latitudeText = event.latitude?.toString() ?: ""
                                longitudeText = event.longitude?.toString() ?: ""
                                showDialog = true
                            }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = event.title, style = MaterialTheme.typography.titleMedium)
                                    Text(text = event.description, style = MaterialTheme.typography.bodyMedium)
                                    event.date?.let {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val formattedDateString = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(it)
                                        Text(
                                            text = stringResource(id = R.string.event_date_prefix, formattedDateString),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (event.latitude != null && event.longitude != null) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        TextButton(onClick = {
                                            val uri = Uri.parse("geo:${event.latitude},${event.longitude}?q=${event.latitude},${event.longitude}")
                                            val intent = Intent(Intent.ACTION_VIEW, uri)
                                            intent.setPackage("com.google.android.apps.maps")
                                            context.startActivity(intent)
                                        }) {
                                            Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(Modifier.width(4.dp))
                                            Text(stringResource(id = R.string.view_location), color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                                Row {
                                    IconButton(onClick = { generatePdfFromEvent(context, event) }) {
                                        Icon(Icons.Default.Download, contentDescription = stringResource(id = R.string.save_to_pdf), tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { viewModel.removeEvent(event) }) {
                                        Icon(Icons.Default.Delete, contentDescription = stringResource(id = R.string.delete), tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }

                            event.photoUri?.let {
                                Spacer(modifier = Modifier.height(8.dp))
                                AsyncImage(
                                    model = Uri.parse(it),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxWidth().height(180.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }

            if (showDialog) {
                val calendar = Calendar.getInstance()
                dateInMillis?.let { calendar.timeInMillis = it }

                val formattedDate = dateInMillis?.let {
                    SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(it)
                } ?: stringResource(id = R.string.dialog_select_date)

                val datePickerDialog = DatePickerDialog(
                    context,
                    { _, year, month, dayOfMonth ->
                        calendar.set(year, month, dayOfMonth)
                        dateInMillis = calendar.timeInMillis
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                )

                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    confirmButton = {
                        TextButton(onClick = {
                            val lat = latitudeText.toDoubleOrNull()
                            val lon = longitudeText.toDoubleOrNull()

                            if (title.isNotBlank()) {
                                if (isEditing && editEventId != null) {
                                    viewModel.editEvent(editEventId!!, title.trim(), description.trim(), photoUri?.toString(), dateInMillis, lat, lon)
                                } else {
                                    viewModel.addEvent(title.trim(), description.trim(), photoUri?.toString(), dateInMillis, lat, lon)
                                }
                                showDialog = false
                            }
                        }) {
                            Text(if (isEditing) stringResource(id = R.string.dialog_save) else stringResource(id = R.string.dialog_add))
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDialog = false }) {
                            Text(stringResource(id = R.string.dialog_cancel))
                        }
                    },
                    title = {
                        Text(if (isEditing) stringResource(id = R.string.dialog_edit_event_title) else stringResource(id = R.string.dialog_new_event_title))
                    },
                    text = {
                        Column {
                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it },
                                label = { Text(stringResource(id = R.string.dialog_field_title)) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = description,
                                onValueChange = { description = it },
                                label = { Text(stringResource(id = R.string.dialog_field_description)) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = { datePickerDialog.show() }) {
                                Text(formattedDate)
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = latitudeText,
                                    onValueChange = { latitudeText = it },
                                    label = { Text(stringResource(id = R.string.dialog_field_latitude)) },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = longitudeText,
                                    onValueChange = { longitudeText = it },
                                    label = { Text(stringResource(id = R.string.dialog_field_longitude)) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            IconButton(onClick = { galleryLauncher.launch("image/*") }) {
                                Icon(Icons.Default.Image, contentDescription = stringResource(id = R.string.dialog_open_gallery))
                            }
                            photoUri?.let {
                                Spacer(modifier = Modifier.height(8.dp))
                                AsyncImage(
                                    model = it,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxWidth().height(180.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                )
            }
        }
    }
}