package com.example.eventora

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.example.eventora.auth.AuthViewModel
import com.example.eventora.auth.LoginScreen
import com.example.eventora.auth.RegisterScreen
import com.example.eventora.navigation.Screen
import com.example.eventora.ui.theme.EventoraTheme
import com.example.eventora.event.EventListScreen
import com.example.eventora.event.EventViewModel
import com.example.eventora.notification.NotificationReceiver
import java.util.*

/**
 * Główna aktywność aplikacji Eventora.
 *
 * Ta klasa stanowi punkt wejścia do aplikacji i odpowiada za:
 * - Konfigurację nawigacji między ekranami
 * - Zarządzanie stanem motywu kolorystycznego i języka
 * - Integrację z systemem uwierzytelniania
 * - Planowanie codziennych powiadomień
 * - Koordynację ViewModeli dla różnych funkcjonalności
 *
 * Aktywność wykorzystuje Jetpack Compose do budowy interfejsu użytkownika
 * oraz Navigation Component do nawigacji między ekranami.
 *
 * ## Funkcjonalności
 * - **Nawigacja**: Automatyczne przekierowanie na podstawie stanu logowania
 * - **Motyw**: Przełączanie między jasnym a ciemnym motywem
 * - **Język**: Obsługa polskiego i angielskiego interfejsu
 * - **Powiadomienia**: Codzienne przypomnienia o godzinie 8:00
 * - **Uwierzytelnianie**: Integracja z systemem logowania/rejestracji
 *
 * ## Struktura nawigacji
 * - `Screen.Login` - Ekran logowania (domyślny punkt startowy)
 * - `Screen.Register` - Ekran rejestracji nowego użytkownika
 * - `Screen.Main` - Główny ekran aplikacji (po zalogowaniu)
 * - `Screen.Events` - Lista wydarzeń dostępnych w aplikacji
 *
 * @see androidx.activity.ComponentActivity
 * @see androidx.navigation.NavHost
 * @see com.example.eventora.auth.AuthViewModel
 * @see com.example.eventora.event.EventViewModel
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        scheduleDailyReminder(this)

        setContent {
            var isDarkTheme by remember { mutableStateOf(false) }

            var isPolishLanguage by remember { mutableStateOf(true) }

            val navController = rememberNavController()

            val authViewModel: AuthViewModel = viewModel()

            val eventViewModel: EventViewModel = viewModel()

            LaunchedEffect(authViewModel.isLoggedIn) {
                if (authViewModel.isLoggedIn) {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(0)
                    }
                }
                if (!authViewModel.isLoggedIn) {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0)
                    }
                }
            }

            EventoraTheme(darkTheme = isDarkTheme) {

                NavHost(navController = navController, startDestination = Screen.Login.route) {

                    composable(Screen.Login.route) {
                        LoginScreen(
                            onLoginClick = { email, password ->
                                authViewModel.login(email, password)
                            },
                            errorMessage = authViewModel.loginError,
                            onRegisterNavigate = { navController.navigate(Screen.Register.route) }
                        )
                    }

                    composable(Screen.Register.route) {
                        RegisterScreen(
                            onRegisterClick = { email, password ->
                                authViewModel.register(email, password)
                            },
                            errorMessage = authViewModel.loginError,
                            onBackToLoginClick = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Main.route) {
                        MainScreen(
                            isDarkTheme = isDarkTheme,
                            onToggleTheme = { isDarkTheme = !isDarkTheme },
                            isPolishLanguage = isPolishLanguage,
                            onToggleLanguage = { isPolishLanguage = !isPolishLanguage },
                            onLogoutClick = { authViewModel.signOut() },
                            onEventsClick = { navController.navigate(Screen.Events.route) }
                        )
                    }

                    composable(Screen.Events.route) {
                        EventListScreen(viewModel = eventViewModel)
                    }
                }
            }
        }
    }

    private fun scheduleDailyReminder(context: Context) {

        val intent = Intent(context, NotificationReceiver::class.java)

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 8)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)

            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }
}