package com.example.eventora

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.app.NotificationCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.example.eventora.auth.AuthViewModel
import com.example.eventora.auth.LoginScreen
import com.example.eventora.auth.RegisterScreen
import com.example.eventora.event.EventListScreen
import com.example.eventora.event.EventViewModel
import com.example.eventora.navigation.Screen
import com.example.eventora.settings.SettingsViewModel
import com.example.eventora.ui.theme.EventoraTheme
import com.example.eventora.utils.LocaleHelper

class MainActivity : ComponentActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var isDarkTheme by remember { mutableStateOf(false) }

            val navController = rememberNavController()
            val settingsViewModel: SettingsViewModel = viewModel()
            val authViewModel: AuthViewModel = viewModel()
            val eventViewModel: EventViewModel = viewModel()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission(),
                    onResult = {}
                )
                LaunchedEffect(Unit) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            val onChangeLanguageLambda = {
                settingsViewModel.changeLanguage(this@MainActivity)
                this@MainActivity.recreate()
            }

            LaunchedEffect(authViewModel.isLoggedIn) {
                if (authViewModel.isLoggedIn) {
                    navController.navigate(Screen.Main.route) { popUpTo(0) }
                } else {
                    val currentRoute = navController.currentBackStackEntry?.destination?.route
                    if (currentRoute != Screen.Login.route && currentRoute != Screen.Register.route) {
                        navController.navigate(Screen.Login.route) { popUpTo(0) }
                    }
                }
            }

            EventoraTheme(darkTheme = isDarkTheme) {
                NavHost(navController = navController, startDestination = Screen.Login.route) {
                    composable(Screen.Login.route) {
                        LoginScreen(
                            onChangeLanguage = onChangeLanguageLambda,
                            onLoginClick = { email, password -> authViewModel.login(email, password) },
                            errorResId = authViewModel.loginErrorResId,
                            onRegisterNavigate = { navController.navigate(Screen.Register.route) }
                        )
                    }
                    composable(Screen.Register.route) {
                        RegisterScreen(
                            onChangeLanguage = onChangeLanguageLambda,
                            onRegisterClick = { email, password -> authViewModel.register(email, password) },
                            errorResId = authViewModel.loginErrorResId,
                            onBackToLoginClick = { navController.popBackStack() }
                        )
                    }
                    composable(Screen.Main.route) {
                        MainScreen(
                            isDarkTheme = isDarkTheme,
                            onToggleTheme = { isDarkTheme = !isDarkTheme },
                            onChangeLanguage = onChangeLanguageLambda,
                            onLogoutClick = { authViewModel.signOut() },
                            onEventsClick = { navController.navigate(Screen.Events.route) },
                            onTestNotificationClick = { showTestNotification() }
                        )
                    }
                    composable(Screen.Events.route) {
                        EventListScreen(viewModel = eventViewModel)
                    }
                }
            }
        }
    }

    private fun showTestNotification() {
        val channelId = "event_notifications"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = getString(R.string.notification_channel_name)
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Testowe Powiadomienie")
            .setContentText("Jeśli to widzisz, powiadomienia działają!")
            .setAutoCancel(true)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}