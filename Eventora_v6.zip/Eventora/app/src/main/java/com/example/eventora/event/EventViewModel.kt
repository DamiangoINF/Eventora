package com.example.eventora.event

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * ViewModel zarządzający danymi wydarzeń w aplikacji Eventora.
 *
 * Odpowiada za interakcję z lokalną bazą danych Room oraz udostępnia dane
 * w formie strumienia `StateFlow`, który obserwowany jest przez interfejs użytkownika.
 *
 * ## Funkcjonalności
 * - Inicjalizacja bazy danych i DAO (Data Access Object)
 * - Obserwacja wszystkich wydarzeń w czasie rzeczywistym
 * - Dodawanie nowych wydarzeń do bazy
 * - Edycja istniejących wydarzeń
 * - Usuwanie wydarzeń z bazy danych
 *
 * Model korzysta z `viewModelScope` do uruchamiania operacji w tle oraz
 * gwarantuje ich anulowanie przy zniszczeniu ViewModelu.
 *
 * @constructor Tworzy `EventViewModel` z kontekstem aplikacji.
 *
 * @param application Kontekst aplikacji wymagany przez `AndroidViewModel`.
 *
 * @see androidx.lifecycle.AndroidViewModel
 * @see kotlinx.coroutines.flow.StateFlow
 * @see com.example.eventora.event.EventDao
 * @see com.example.eventora.event.EventDatabase
 */
class EventViewModel(application: Application) : AndroidViewModel(application) {

    private val eventDao: EventDao

    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> = _events.asStateFlow()

    init {
        val db = Room.databaseBuilder(
            application,
            EventDatabase::class.java,
            "event_database"
        )
            .fallbackToDestructiveMigration()
            .build()

        eventDao = db.eventDao()

        observeEvents()
    }

    private fun observeEvents() {
        viewModelScope.launch {
            eventDao.getAllEvents().collectLatest { eventList ->
                _events.value = eventList
            }
        }
    }

    fun addEvent(
        title: String,
        description: String,
        photoUri: String?,
        date: Long?,
        latitude: Double? = null,
        longitude: Double? = null
    ) = viewModelScope.launch {
        val event = Event(
            title = title.trim(),
            description = description.trim(),
            photoUri = photoUri,
            date = date,
            latitude = latitude,
            longitude = longitude
        )
        eventDao.insert(event)
    }

    fun removeEvent(event: Event) = viewModelScope.launch {
        eventDao.delete(event)
    }

    fun editEvent(
        id: Int,
        newTitle: String,
        newDescription: String,
        newPhotoUri: String?,
        newDate: Long?,
        newLatitude: Double? = null,
        newLongitude: Double? = null
    ) = viewModelScope.launch {
        val updatedEvent = Event(
            id = id,
            title = newTitle.trim(),
            description = newDescription.trim(),
            photoUri = newPhotoUri,
            date = newDate,
            latitude = newLatitude,
            longitude = newLongitude
        )
        eventDao.update(updatedEvent)
    }
}