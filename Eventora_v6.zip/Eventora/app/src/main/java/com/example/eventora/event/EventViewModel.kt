package com.example.eventora.event

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventora.notification.AlarmScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EventViewModel(application: Application) : AndroidViewModel(application) {

    private val eventDao: EventDao
    private val alarmScheduler: AlarmScheduler

    val events: StateFlow<List<Event>>

    init {
        val db = EventDatabase.getDatabase(application)
        eventDao = db.eventDao()
        alarmScheduler = AlarmScheduler(application.applicationContext)

        events = eventDao.getAllEvents().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun addEvent(
        title: String,
        description: String,
        photoUri: String?,
        date: Long?,
        latitude: Double? = null,
        longitude: Double? = null
    ) = viewModelScope.launch {
        val event = Event(
            title = title.trim(),
            description = description.trim(),
            photoUri = photoUri,
            date = date,
            latitude = latitude,
            longitude = longitude
        )
        val newId = eventDao.insert(event)

        alarmScheduler.schedule(event.copy(id = newId.toInt()))
    }

    fun removeEvent(event: Event) = viewModelScope.launch {
        alarmScheduler.cancel(event)
        eventDao.delete(event)
    }

    fun editEvent(
        id: Int,
        newTitle: String,
        newDescription: String,
        newPhotoUri: String?,
        newDate: Long?,
        newLatitude: Double? = null,
        newLongitude: Double? = null
    ) = viewModelScope.launch {
        val updatedEvent = Event(
            id = id,
            title = newTitle.trim(),
            description = newDescription.trim(),
            photoUri = newPhotoUri,
            date = newDate,
            latitude = newLatitude,
            longitude = newLongitude
        )
        eventDao.update(updatedEvent)
        alarmScheduler.schedule(updatedEvent)
    }
}