package com.example.eventora.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Ekran logowania użytkownika w aplikacji Eventora.
 *
 * Komponent `LoginScreen` umożliwia użytkownikowi wprowadzenie danych logowania
 * (email i hasło) oraz przesłanie ich do funkcji logującej. Zawiera także opcję
 * przejścia do ekranu rejestracji i wyświetlania błędów logowania.
 *
 * ## Funkcjonalności
 * - Wprowadzanie adresu e-mail i hasła
 * - Przycisk logowania z walidacją pustych pól
 * - Przejście do ekranu rejestracji
 * - Wyświetlanie błędów logowania (np. niepoprawne dane)
 *
 * @param onLoginClick Funkcja callback wywoływana po kliknięciu przycisku logowania.
 *                     Otrzymuje wprowadzone email i hasło jako argumenty.
 * @param errorMessage Opcjonalny komunikat błędu wyświetlany pod formularzem logowania.
 * @param onRegisterNavigate Funkcja callback umożliwiająca nawigację do ekranu rejestracji.
 *
 * @sample
 * ```kotlin
 * LoginScreen(
 *     onLoginClick = { email, password -> login(email, password) },
 *     errorMessage = "Nieprawidłowe dane logowania",
 *     onRegisterNavigate = { navigateToRegister() }
 * )
 * ```
 *
 * @see androidx.compose.material3.OutlinedTextField
 * @see androidx.compose.material3.Button
 * @see androidx.compose.material3.TextButton
 */
@Composable
fun LoginScreen(
    onLoginClick: (String, String) -> Unit,
    errorMessage: String?,
    onRegisterNavigate: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Zaloguj się",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Hasło") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { onLoginClick(email.trim(), password) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Zaloguj")
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = onRegisterNavigate) {
            Text("Nie masz konta? Zarejestruj się")
        }

        if (!errorMessage.isNullOrEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
    }
}