package com.example.eventora.event

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {

    @Query("SELECT * FROM events ORDER BY id DESC")
    fun getAllEvents(): Flow<List<Event>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: Event): Long

    @Delete
    suspend fun delete(event: Event)

    @Update
    suspend fun update(event: Event)

    // @Query("SELECT * FROM events")
    // suspend fun getAllEventsOnce(): List<Event>

    @Query("SELECT * FROM events WHERE date > :currentTimeMillis ORDER BY date ASC")
    suspend fun getFutureEvents(currentTimeMillis: Long): List<Event>
}