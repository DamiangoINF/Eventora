package com.example.eventora.event

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Interfejs DAO (Data Access Object) dla operacji na tabeli `events` w bazie danych.
 *
 * `EventDao` definiuje metody dostępu do danych wydarzeń w lokalnej bazie danych Room.
 * Umożliwia pobieranie, dodawanie, usuwanie oraz aktualizowanie danych typu `Event`.
 *
 * ## Funkcjonalności
 * - Strumieniowe pobieranie listy wydarzeń (`Flow`)
 * - Jednorazowe pobieranie listy wydarzeń (`suspend`)
 * - Wstawianie, usuwanie i aktualizacja danych z użyciem adnotacji Room
 *
 * @see androidx.room.Dao
 * @see Event
 * @see androidx.room.RoomDatabase
 */
@Dao
interface EventDao {

    @Query("SELECT * FROM events ORDER BY id DESC")
    fun getAllEvents(): Flow<List<Event>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: Event)

    @Delete
    suspend fun delete(event: Event)

    @Update
    suspend fun update(event: Event)

    @Query("SELECT * FROM events")
    suspend fun getAllEventsOnce(): List<Event>
}