package com.example.eventora.event

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Reprezentacja danych wydarzenia w bazie danych Room.
 *
 * Klasa `Event` definiuje strukturę tabeli `events` w lokalnej bazie danych.
 * Każde wydarzenie zawiera tytuł, opis, znacznik czasu, opcjonalne zdjęcie,
 * datę oraz lokalizację GPS (szerokość i długość geograficzną).
 *
 * ## Pola
 * @property id Unikalny identyfikator wydarzenia (generowany automatycznie).
 * @property title Tytuł wydarzenia, wymagany.
 * @property description Opis wydarzenia, wymagany.
 * @property timestamp Znacznik czasu utworzenia rekordu (domyślnie bieżący czas).
 * @property photoUri URI do opcjonalnego zdjęcia powiązanego z wydarzeniem.
 * @property date Data wydarzenia w formacie `Long` (np. do konwersji na `Date`).
 * @property latitude Opcjonalna szerokość geograficzna miejsca wydarzenia.
 * @property longitude Opcjonalna długość geograficzna miejsca wydarzenia.
 *
 * @see androidx.room.Entity
 * @see androidx.room.PrimaryKey
 */
@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val photoUri: String? = null,
    val date: Long? = null,
    val latitude: Double? = null,
    val longitude: Double? = null
)