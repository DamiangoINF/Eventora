package com.example.eventora.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Konfiguracja typografii dla aplikacji Eventora.
 *
 * Ten obiekt `Typography` definiuje styl tekstu używanego w komponentach Material 3,
 * w tym domyślny styl dla `bodyLarge`, który jest najczęściej stosowanym stylem tekstu w aplikacji.
 *
 * ## Funkcjonalności
 * - Określa domyślną rodzinę czcionek, rozmiar, wysokość linii i odstęp między literami
 * - Umożliwia spójny wygląd tekstów w całej aplikacji
 *
 * @see androidx.compose.material3.Typography
 * @see androidx.compose.ui.text.TextStyle
 */
val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    )
)