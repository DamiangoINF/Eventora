package com.example.eventora.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Odbiornik ekranu dla aplikacji Eventora.
 *
 * Klasa `ScreenReceiver` nasłuchuje na zdarzenie włączenia ekranu (`ACTION_SCREEN_ON`)
 * i aktualizuje widżet aplikacji po odblokowaniu urządzenia.
 *
 * ## Funkcjonalności
 * - Automatyczne odświeżenie widżetu wydarzeń po włączeniu ekranu
 *
 * @see android.content.BroadcastReceiver
 * @see android.content.Intent.ACTION_SCREEN_ON
 * @see EventAppWidgetProvider.updateWidget
 */
class ScreenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_SCREEN_ON) {
            EventAppWidgetProvider().updateWidget(context)
        }
    }
}