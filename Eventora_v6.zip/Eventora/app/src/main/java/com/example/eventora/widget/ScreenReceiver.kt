package com.example.eventora.widget

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent

class ScreenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_SCREEN_ON) {
            val refreshIntent = Intent(context, EventAppWidgetProvider::class.java).apply {
                action = EventAppWidgetProvider.ACTION_REFRESH_WIDGET
            }

            context.sendBroadcast(refreshIntent)
        }
    }
}