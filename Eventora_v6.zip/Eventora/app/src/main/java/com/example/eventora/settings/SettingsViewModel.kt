package com.example.eventora.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import com.example.eventora.utils.LocaleHelper

class SettingsViewModel : ViewModel() {

    /**
     * Zmienia język aplikacji, opierając się na najbardziej niezawodnym źródle -
     * wartości zapisanej w SharedPreferences.
     *
     * @param context Kontekst jest potrzebny do uzyskania dostępu do SharedPreferences.
     */
    fun changeLanguage(context: Context) {
        val currentLang = LocaleHelper.getPersistedLanguage(context)

        val newLang = if (currentLang == "pl") "en" else "pl"

        LocaleHelper.setLocale(context, newLang)
    }
}