package com.example.eventora

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import com.example.eventora.auth.AuthViewModel

class AuthViewModelTest {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var authViewModel: AuthViewModel


    @Test
    fun `login with empty credentials should set error`() {
        authViewModel.login("", "")

        assertEquals("Email i hasło są wymagane", authViewModel.loginError)
        assertFalse(authViewModel.isLoggedIn)
    }

    @Test
    fun `signOut should clear logged in state`() {
        authViewModel.signOut()

        assertFalse(authViewModel.isLoggedIn)
    }
}