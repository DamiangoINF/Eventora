package com.example.eventora.widget

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.eventora.event.Event
import com.example.eventora.event.EventDatabase
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WidgetTest {

    @Test
    fun widget_updatesWithUpcomingEvent() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dao = EventDatabase.getDatabase(context).eventDao()

        dao.insert(Event(title = "Test Widget", description = "Opis", date = System.currentTimeMillis() + 1000000))

        EventAppWidgetProvider().updateWidget(context)
    }
}