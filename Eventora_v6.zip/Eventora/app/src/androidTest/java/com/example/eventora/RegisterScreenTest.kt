package com.example.eventora
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.runner.RunWith
import com.example.eventora.auth.RegisterScreen

@RunWith(AndroidJUnit4::class)
class RegisterScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun registerScreen_displaysAllRequiredElements() {
        composeTestRule.setContent {
            RegisterScreen(
                onRegisterClick = { _, _ -> },
                errorMessage = null,
                onBackToLoginClick = { }
            )
        }

        composeTestRule.onNodeWithText("Zarejestruj się").assertIsDisplayed()
        composeTestRule.onNodeWithText("Email").assertIsDisplayed()
        composeTestRule.onNodeWithText("Hasło").assertIsDisplayed()
        composeTestRule.onNodeWithText("Zarejestruj").assertIsDisplayed()
        composeTestRule.onNodeWithText("Masz już konto? Zaloguj się").assertIsDisplayed()
    }

    @Test
    fun registerScreen_registerButton_triggersCallback() {
        val testEmail = "newuser@example.com"
        val testPassword = "newpassword123"
        var capturedEmail = ""
        var capturedPassword = ""

        composeTestRule.setContent {
            RegisterScreen(
                onRegisterClick = { email, password ->
                    capturedEmail = email
                    capturedPassword = password
                },
                errorMessage = null,
                onBackToLoginClick = { }
            )
        }

        composeTestRule.onNodeWithText("Email").performTextInput(testEmail)
        composeTestRule.onNodeWithText("Hasło").performTextInput(testPassword)
        composeTestRule.onNodeWithText("Zarejestruj").performClick()

        assertEquals(testEmail, capturedEmail)
        assertEquals(testPassword, capturedPassword)
    }

    @Test
    fun registerScreen_backToLoginButton_triggersNavigation() {
        var backToLoginCalled = false

        composeTestRule.setContent {
            RegisterScreen(
                onRegisterClick = { _, _ -> },
                errorMessage = null,
                onBackToLoginClick = { backToLoginCalled = true }
            )
        }

        composeTestRule.onNodeWithText("Masz już konto? Zaloguj się").performClick()

        assertTrue(backToLoginCalled)
    }
}