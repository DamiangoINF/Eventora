package com.example.eventora

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.eventora.ui.theme.EventoraTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun mainScreen_displaysCorrectGreetingInPolish() {
        var themeToggled = false
        var languageToggled = false
        var logoutClicked = false
        var eventsClicked = false

        composeTestRule.setContent {
            EventoraTheme {
                MainScreen(
                    isDarkTheme = false,
                    onToggleTheme = { themeToggled = true },
                    isPolishLanguage = true,
                    onToggleLanguage = { languageToggled = true },
                    onLogoutClick = { logoutClicked = true },
                    onEventsClick = { eventsClicked = true }
                )
            }
        }

        composeTestRule
            .onNodeWithTag("GreetingText")
            .assertIsDisplayed()
            .assertTextContains("Witaj w Eventora!")
    }

    @Test
    fun mainScreen_displaysCorrectGreetingInEnglish() {
        var themeToggled = false
        var languageToggled = false
        var logoutClicked = false
        var eventsClicked = false

        composeTestRule.setContent {
            EventoraTheme {
                MainScreen(
                    isDarkTheme = false,
                    onToggleTheme = { themeToggled = true },
                    isPolishLanguage = false,
                    onToggleLanguage = { languageToggled = true },
                    onLogoutClick = { logoutClicked = true },
                    onEventsClick = { eventsClicked = true }
                )
            }
        }

        composeTestRule
            .onNodeWithTag("GreetingText")
            .assertIsDisplayed()
            .assertTextContains("Welcome to Eventora!")
    }

    @Test
    fun mainScreen_themeToggleButtonClickTriggersCallback() {
        var themeToggled = false
        var languageToggled = false
        var logoutClicked = false
        var eventsClicked = false

        composeTestRule.setContent {
            EventoraTheme {
                MainScreen(
                    isDarkTheme = false,
                    onToggleTheme = { themeToggled = true },
                    isPolishLanguage = true,
                    onToggleLanguage = { languageToggled = true },
                    onLogoutClick = { logoutClicked = true },
                    onEventsClick = { eventsClicked = true }
                )
            }
        }

        composeTestRule
            .onNodeWithTag("ToggleThemeButton")
            .performClick()

        assert(themeToggled) { "Theme toggle callback should be triggered" }
        assert(!languageToggled) { "Language toggle should not be triggered" }
        assert(!logoutClicked) { "Logout should not be triggered" }
        assert(!eventsClicked) { "Events click should not be triggered" }
    }

    @Test
    fun mainScreen_languageToggleButtonClickTriggersCallback() {
        var themeToggled = false
        var languageToggled = false
        var logoutClicked = false
        var eventsClicked = false

        composeTestRule.setContent {
            EventoraTheme {
                MainScreen(
                    isDarkTheme = false,
                    onToggleTheme = { themeToggled = true },
                    isPolishLanguage = true,
                    onToggleLanguage = { languageToggled = true },
                    onLogoutClick = { logoutClicked = true },
                    onEventsClick = { eventsClicked = true }
                )
            }
        }

        composeTestRule
            .onNodeWithTag("ToggleLanguageButton")
            .performClick()

        assert(languageToggled) { "Language toggle callback should be triggered" }
        assert(!themeToggled) { "Theme toggle should not be triggered" }
        assert(!logoutClicked) { "Logout should not be triggered" }
        assert(!eventsClicked) { "Events click should not be triggered" }
    }
}