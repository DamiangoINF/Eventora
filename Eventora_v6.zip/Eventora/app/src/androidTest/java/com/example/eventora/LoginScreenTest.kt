package com.example.eventora

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.runner.RunWith
import com.example.eventora.auth.LoginScreen

@RunWith(AndroidJUnit4::class)
class LoginScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun loginScreen_displaysAllRequiredElements() {
        composeTestRule.setContent {
            LoginScreen(
                onLoginClick = { _, _ -> },
                errorMessage = null,
                onRegisterNavigate = { }
            )
        }

        composeTestRule.onNodeWithText("Zaloguj się").assertIsDisplayed()
        composeTestRule.onNodeWithText("Email").assertIsDisplayed()
        composeTestRule.onNodeWithText("Hasło").assertIsDisplayed()
        composeTestRule.onNodeWithText("Zaloguj").assertIsDisplayed()
        composeTestRule.onNodeWithText("Nie masz konta? Zarejestruj się").assertIsDisplayed()
    }

    @Test
    fun loginScreen_loginButton_triggersCallback() {
        val testEmail = "test@example.com"
        val testPassword = "password123"
        var capturedEmail = ""
        var capturedPassword = ""

        composeTestRule.setContent {
            LoginScreen(
                onLoginClick = { email, password ->
                    capturedEmail = email
                    capturedPassword = password
                },
                errorMessage = null,
                onRegisterNavigate = { }
            )
        }

        composeTestRule.onNodeWithText("Email").performTextInput(testEmail)
        composeTestRule.onNodeWithText("Hasło").performTextInput(testPassword)
        composeTestRule.onNodeWithText("Zaloguj").performClick()

        assertEquals(testEmail, capturedEmail)
        assertEquals(testPassword, capturedPassword)
    }

    @Test
    fun loginScreen_displaysErrorMessage() {
        val errorMessage = "Błąd logowania"

        composeTestRule.setContent {
            LoginScreen(
                onLoginClick = { _, _ -> },
                errorMessage = errorMessage,
                onRegisterNavigate = { }
            )
        }

        composeTestRule.onNodeWithText(errorMessage).assertIsDisplayed()
    }
}